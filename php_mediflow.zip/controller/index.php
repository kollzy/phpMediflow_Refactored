<?php
// load your header/menu
include __DIR__ . "/../html/menu.html";

?>

<h1>Welcome to MediFlow</h1>
<p>Select an option from the menu above to continue.</p>

<?php
// optionally include footer if you have one
// include __DIR__ . "/html/footer.html";
?>
